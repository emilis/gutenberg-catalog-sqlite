
exports.testDirname = require('./dirname');
exports.testExtension = require('./extension');
exports.testIsAbsolute = require('./is-absolute');
exports.testIterator = require('./iterator');
exports.testNormal = require('./normal');
exports.testRelative = require('./relative');
exports.testResolve = require('./resolve');