This is a minimal RingoJS application. To run it launch ringo
with the main script:

  ringo main.js

Then point your browser to this URL:

  http://localhost:8080/
